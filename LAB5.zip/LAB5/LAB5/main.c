/*
 * SErvo
 *
 */
/****************************************/
// Encabezado (Libraries)
#define F_CPU 16000000UL
#include <avr/io.h>
#include <stdint.h>

/****************************************/
// Function prototypes
void setup(void);
void initADC(void);
uint16_t readADC(uint8_t channel);
void initPWM1(void);

/****************************************/
// Main Function
int main(void)
{
	uint16_t adcValue = 0;
	uint16_t pwmValue = 0;
	
	setup();
	
	while (1)
	{
		// Leer el canal analogico A7
		adcValue = readADC(7);
		
		// Convertir el valor ADC de 0-1023
		// a un pulso para servo entre 1 ms y 2 ms
		// con Timer 1 configurado a 50 Hz
		// 1 ms = 2000 cuentas
		// 2 ms = 4000 cuentas
		pwmValue = 2000 + ((uint32_t)adcValue * 2000UL) / 1023UL;
		
		// Actualizar la salida OC1B en D10
		OCR1B = pwmValue;
	}
}

/****************************************/
// NON-Interrupt subroutines
void setup(void)
{
	initADC();
	initPWM1();
}

void initADC(void)
{
	// Referencia en AVcc
	// Canal inicial ADC0, luego se cambia al leer
	ADMUX = 0;
	ADMUX |= (1 << REFS0);
	
	// Habilitar convertidor analogico digital
	// Prescaler de 128
	ADCSRA = 0;
	ADCSRA |= (1 << ADEN);
	ADCSRA |= (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
}

uint16_t readADC(uint8_t channel)
{
	// Limpiar seleccion previa del canal
	ADMUX &= 0xF0;
	
	// Colocar nuevo canal
	ADMUX |= (channel & 0x0F);
	
	// Iniciar conversion
	ADCSRA |= (1 << ADSC);
	
	// Esperar a que termine la conversion
	while (ADCSRA & (1 << ADSC));
	
	// Retornar resultado de 10 bits
	return ADC;
}

void initPWM1(void)
{
	// D10 = PB2 = OC1B como salida
	DDRB |= (1 << PB2);
	
	// Timer 1 en modo Fast PWM con TOP = ICR1
	// Salida no invertida en OC1B
	TCCR1A = 0;
	TCCR1B = 0;
	
	TCCR1A |= (1 << COM1B1);
	TCCR1A |= (1 << WGM11);
	
	TCCR1B |= (1 << WGM13) | (1 << WGM12);
	TCCR1B |= (1 << CS11);
	
	// Frecuencia de 50 Hz para servo
	// f_PWM = f_clk / (Prescaler * (1 + TOP))
	// 50 = 16000000 / (8 * (1 + TOP))
	// TOP = 39999
	ICR1 = 39999;
	
	// Posicion inicial al centro
	OCR1B = 3000;
}

/****************************************/
// Interrupt routines