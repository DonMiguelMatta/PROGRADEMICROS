/*
 * lab6
 *
 * Created: 
 * Author: Miguel Donis
 * Description:
 */
/****************************************/
// Encabezado (Libraries)

#define F_CPU 16000000UL
#include <avr/io.h>

/****************************************/
// Function prototypes

void USART_Init(void);
void USART_Transmit(unsigned char data);
unsigned char USART_Receive(void);
void Mostrar_Byte_En_LEDs(unsigned char dato);

/****************************************/
// Main Function

int main(void)
{
    unsigned char dato;

    // D2-D7 como salida
    DDRD |= (1 << DDD2) | (1 << DDD3) | (1 << DDD4) |
            (1 << DDD5) | (1 << DDD6) | (1 << DDD7);

    // D8-D9 como salida
    DDRB |= (1 << DDB0) | (1 << DDB1);

    // Limpia leds
    PORTD &= ~((1 << PORTD2) | (1 << PORTD3) | (1 << PORTD4) |
               (1 << PORTD5) | (1 << PORTD6) | (1 << PORTD7));
    PORTB &= ~((1 << PORTB0) | (1 << PORTB1));

    // Inicializa USART
    USART_Init();

    // Parte 1: envia una sola vez 'A'
    USART_Transmit('A');

    while (1)
    {
        // Parte 2: espera un caracter nuevo
        dato = USART_Receive();

        // Muestra dato en leds y lo mantiene
        Mostrar_Byte_En_LEDs(dato);
    }
}

/****************************************/
// NON-Interrupt subroutines

void USART_Init(void)
{
    // Baud rate 9600 para 16 MHz
    UBRR0H = 0;
    UBRR0L = 103;

    // Modo asincrono normal
    UCSR0A = 0x00;

    // Habilita receptor y transmisor
    UCSR0B = (1 << RXEN0) | (1 << TXEN0);

    // 8 bits, sin paridad, 1 bit de parada
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

void USART_Transmit(unsigned char data)
{
    // Espera buffer vacio
    while (!(UCSR0A & (1 << UDRE0)));

    // Envia dato
    UDR0 = data;
}

unsigned char USART_Receive(void)
{
    // Espera dato recibido
    while (!(UCSR0A & (1 << RXC0)));

    // Retorna dato
    return UDR0;
}

void Mostrar_Byte_En_LEDs(unsigned char dato)
{
    // Limpia D2-D7
    PORTD &= ~((1 << PORTD2) | (1 << PORTD3) | (1 << PORTD4) |
               (1 << PORTD5) | (1 << PORTD6) | (1 << PORTD7));

    // Limpia D8-D9
    PORTB &= ~((1 << PORTB0) | (1 << PORTB1));

    // Bit 0 a bit 5 en D2-D7
    PORTD |= ((dato & 0x3F) << 2);

    // Bit 6 y bit 7 en D8-D9
    PORTB |= ((dato >> 6) & 0x03);
}

/****************************************/
// Interrupt routines